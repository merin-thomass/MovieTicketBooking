package com.UserService.userservice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;


@Service
public class UserServices {
	
	@Autowired
	public UserRepository repo;
	
	
	public List<User> getAllUser(){
		List<User> users= new ArrayList<>();
		 repo.findAll().forEach(users::add);
		
		 return users;
		
	}
	
	public void addUser( User user) {
		repo.save(user);
	}
	
	public void dlt(int id) {
		repo.deleteById(id);
		
	}
	
	public Optional<User> findUser(int id) {
		Optional<User> users= repo.findById(id);
		return users;
	}
		
				
			

}

