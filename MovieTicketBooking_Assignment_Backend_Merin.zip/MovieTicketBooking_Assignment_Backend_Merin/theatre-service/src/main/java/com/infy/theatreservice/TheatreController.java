package com.infy.theatreservice;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TheatreController {
	
	@Autowired
	private TheatreService service;
	
	@PostMapping(value="/add_theatre")
	public ResponseEntity<Theatre> addTheatre(@Valid @RequestBody Theatre theatre)
	{
		return new ResponseEntity<>(service.addTheatre(theatre),HttpStatus.OK);
	}
	
	@GetMapping(value="/AllTheatres")
	public  ResponseEntity<List<Theatre>>getTheatres()
	{
		return new ResponseEntity<>(service.getTheatres(),HttpStatus.OK);
	}
	
	@GetMapping(value="/theatre/{id}")
	public  ResponseEntity<Theatre>getTheatreById(@PathVariable("id") Integer id)
	{
		return new ResponseEntity<>(service.getTheatre(id),HttpStatus.OK);
	}
	
	@GetMapping(value="/theatre/name/{theatreName}")
	public  ResponseEntity<List<Theatre>>getTheatreByTheatreName(@PathVariable("theatreName") String theatreName )
	{
		return new ResponseEntity<>(service.getTheatreBytheatreName(theatreName),HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/updatetheatre/{id}")
    public ResponseEntity<Theatre> updateDetails(@PathVariable("id") Integer id,@Valid @RequestBody Theatre theatre){
        return new ResponseEntity<>(service.updateDetails(id, theatre), HttpStatus.OK);
    }
    
    @DeleteMapping(path = "/theatre/{id}")
    public ResponseEntity <Void> deleteTheatre(@PathVariable("id") Integer id){
    service.deleteByTheatreId(id);
    return new ResponseEntity<Void>(HttpStatus.OK);
	
    }
}
