package com.infy.theatreservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TheatreService {
	
	@Autowired
    TheatreRepository theatrerepo;
	
	public Theatre addTheatre(Theatre theatre) {
		
		return theatrerepo.save(theatre);
	}
	
	public List<Theatre> getTheatres() {
		return (List<Theatre>) theatrerepo.findAll();
	}
	
	public Theatre getTheatre(Integer id) {
		return theatrerepo.findById(id).get();
	}

	public Theatre updateDetails(Integer id,Theatre theatre) {
		theatre.setTheatreId(id);
		return theatrerepo.save(theatre);
	}


	public List<Theatre> getTheatreBytheatreName(String theatreName) {
		return (List<Theatre>) theatrerepo.findBytheatreName(theatreName);
	}

	public void deleteByTheatreId(Integer id) {
		theatrerepo.deleteById(id);
	}

}
