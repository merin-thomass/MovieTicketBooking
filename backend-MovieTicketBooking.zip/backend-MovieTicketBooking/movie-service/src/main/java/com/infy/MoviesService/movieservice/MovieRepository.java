package com.infy.MoviesService.movieservice;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface MovieRepository extends CrudRepository<Movie, Integer>{

	public Movie findBymovieName(String movieName); 
	
}

// Method to retrieve movies by movieName
	//Here the return type is given as List for showing that a list of items can be retrieved as a result
	//Actual use case of movie returns only a single movie with the given name
